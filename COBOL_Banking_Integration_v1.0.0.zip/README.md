# COBOL Banking Integration for SuiteCRM

## Quick Installation

1. Upload this package via Admin → Module Loader
2. Install the package
3. Start COBOL services:
   ```bash
   docker-compose -f docker-compose-cobol.yml up -d
   ```
4. Configure via Admin → COBOL Banking Integration

## Features

- COBOL-powered financial calculations
- Mainframe synchronization
- Real-time transaction streaming
- Banking-grade decimal precision
- Legacy authentication bridge

## Support

- Documentation: See docs/ folder
- Issues: https://github.com/jfuginay/suitecrm-cobol-banking/issues
