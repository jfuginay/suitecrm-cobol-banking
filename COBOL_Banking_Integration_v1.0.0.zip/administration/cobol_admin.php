<?php
$admin_option_defs['Administration']['cobol_config'] = array(
    'Administration',
    'LBL_COBOL_CONFIG_TITLE',
    'LBL_COBOL_CONFIG_DESC',
    'index.php?module=Administration&action=COBOLConfig'
);
