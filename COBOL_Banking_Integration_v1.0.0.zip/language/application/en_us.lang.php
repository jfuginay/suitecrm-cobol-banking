<?php
$mod_strings['LBL_COBOL_CONFIG_TITLE'] = 'COBOL Banking Integration';
$mod_strings['LBL_COBOL_CONFIG_DESC'] = 'Configure COBOL mainframe integration for banking operations';
$mod_strings['LBL_COBOL_BRIDGE'] = 'COBOL Bridge';
$mod_strings['LBL_MAINFRAME_SYNC'] = 'Mainframe Sync';
$mod_strings['LBL_TRANSACTION_LEDGER'] = 'Transaction Ledger';
