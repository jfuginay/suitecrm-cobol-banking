<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function pre_uninstall() {
    // Stop Docker services if running
    $docker_check = shell_exec('docker ps --filter name=suitecrm-cobol-engine --format "{{.Names}}" 2>&1');
    if (trim($docker_check) === 'suitecrm-cobol-engine') {
        shell_exec('docker-compose -f docker-compose-cobol.yml down 2>&1');
    }
}
