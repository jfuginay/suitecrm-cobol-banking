<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function post_uninstall() {
    global $db;
    
    // Clean up configuration
    require_once('modules/Administration/Administration.php');
    $admin = BeanFactory::newBean('Administration');
    $admin->removeSettings('cobol');
    
    // Note: We don't drop tables by default to preserve data
    $GLOBALS['log']->info('COBOL Banking Integration uninstalled. Database tables preserved.');
}
