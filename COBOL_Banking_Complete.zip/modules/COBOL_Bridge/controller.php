<?php
/**
 * COBOL Bridge Controller
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class COBOL_BridgeController extends SugarController {
    
    /**
     * Display the financial calculator view
     */
    public function action_calculator() {
        $this->view = 'calculator';
    }
    
    /**
     * Display the mainframe sync view
     */
    public function action_mainframe_sync() {
        $this->view = 'mainframe_sync';
    }
    
    /**
     * Display transaction ledger
     */
    public function action_transaction_ledger() {
        $this->view = 'transaction_ledger';
    }
    
    /**
     * Handle batch processing
     */
    public function action_batch_process() {
        $this->view = 'batch_process';
    }
    
    /**
     * Display audit log
     */
    public function action_audit_log() {
        $this->view = 'audit_log';
    }
    
    /**
     * Log sync operation (AJAX)
     */
    public function action_LogSync() {
        global $db;
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $id = create_guid();
        $sync_type = $db->quote($data['sync_type']);
        $status = $db->quote($data['status']);
        $records_synced = intval($data['records_synced']);
        $error_message = $db->quote($data['error_message']);
        $started_at = date('Y-m-d H:i:s');
        
        $sql = "INSERT INTO mainframe_sync_log 
                (id, sync_type, status, records_synced, error_message, started_at, sync_direction) 
                VALUES 
                ('$id', $sync_type, $status, $records_synced, $error_message, '$started_at', 'INBOUND')";
        
        $db->query($sql);
        
        echo json_encode(array('success' => true));
        exit;
    }
    
    /**
     * Start Docker services
     */
    public function action_StartServices() {
        if (!is_admin($GLOBALS['current_user'])) {
            sugar_die('Admin access required');
        }
        
        $output = shell_exec('cd ' . dirname(__FILE__) . ' && docker-compose -f docker-compose-cobol.yml up -d 2>&1');
        
        echo json_encode(array(
            'success' => true,
            'output' => $output
        ));
        exit;
    }
    
    /**
     * Stop Docker services
     */
    public function action_StopServices() {
        if (!is_admin($GLOBALS['current_user'])) {
            sugar_die('Admin access required');
        }
        
        $output = shell_exec('cd ' . dirname(__FILE__) . ' && docker-compose -f docker-compose-cobol.yml down 2>&1');
        
        echo json_encode(array(
            'success' => true,
            'output' => $output
        ));
        exit;
    }
    
    /**
     * View Docker logs
     */
    public function action_ViewLogs() {
        if (!is_admin($GLOBALS['current_user'])) {
            sugar_die('Admin access required');
        }
        
        $logs = shell_exec('docker logs cobol-calculation-engine --tail 100 2>&1');
        
        echo '<pre>' . htmlspecialchars($logs) . '</pre>';
        echo '<br><a href="javascript:window.close()">Close</a>';
        exit;
    }
}