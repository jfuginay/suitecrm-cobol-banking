<?php
/**
 * COBOL Bridge Module for SuiteCRM
 * Provides integration with COBOL financial calculation services
 * 
 * @package SuiteCRM\modules\COBOL_Bridge
 * @author SuiteCRM-COBOL Integration Team
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class COBOL_Bridge extends Basic
{
    public $module_dir = 'COBOL_Bridge';
    public $object_name = 'COBOL_Bridge';
    public $table_name = 'cobol_bridge';
    public $new_schema = true;
    public $module_name = 'COBOL_Bridge';
    
    private $cobol_api_url;
    private $cache_enabled = true;
    private $cache_ttl = 300; // 5 minutes
    
    public function __construct()
    {
        parent::__construct();
        $this->cobol_api_url = $this->getCobolApiUrl();
    }
    
    /**
     * Get COBOL API URL from configuration
     */
    private function getCobolApiUrl()
    {
        global $sugar_config;
        return isset($sugar_config['cobol_api_url']) 
            ? $sugar_config['cobol_api_url'] 
            : 'http://cobol-engine:3000';
    }
    
    /**
     * Calculate loan payment using COBOL
     * 
     * @param float $principal Loan principal amount
     * @param float $rate Annual interest rate (as decimal)
     * @param int $term Loan term in months
     * @return array Calculation results
     */
    public function calculateLoanPayment($principal, $rate, $term)
    {
        $cacheKey = "loan_payment_{$principal}_{$rate}_{$term}";
        
        // Check cache first
        if ($this->cache_enabled) {
            $cached = $this->getFromCache($cacheKey);
            if ($cached !== false) {
                return $cached;
            }
        }
        
        $data = [
            'type' => 'LOAN-PAYMENT',
            'principal' => $principal,
            'rate' => $rate,
            'term' => $term
        ];
        
        $result = $this->callCobolService('/calculate', $data);
        
        // Cache the result
        if ($this->cache_enabled && $result['status'] === 'success') {
            $this->saveToCache($cacheKey, $result);
        }
        
        return $result;
    }
    
    /**
     * Calculate compound interest using COBOL
     * 
     * @param float $principal Initial amount
     * @param float $rate Interest rate
     * @param int $term Term in days
     * @param int $compoundFreq Compounding frequency (times per year)
     * @return array Calculation results
     */
    public function calculateCompoundInterest($principal, $rate, $term, $compoundFreq = 365)
    {
        $data = [
            'type' => 'COMPOUND-INTEREST',
            'principal' => $principal,
            'rate' => $rate,
            'term' => $term,
            'compoundFreq' => $compoundFreq
        ];
        
        return $this->callCobolService('/calculate', $data);
    }
    
    /**
     * Calculate invoice total with tax and discounts using COBOL
     * 
     * @param array $lineItems Array of line items
     * @return array Calculation results
     */
    public function calculateInvoiceTotal($lineItems)
    {
        $data = [
            'type' => 'INVOICE-TOTAL',
            'lineItems' => $lineItems
        ];
        
        return $this->callCobolService('/calculate', $data);
    }
    
    /**
     * Calculate quote total using COBOL
     * 
     * @param array $lineItems Array of line items
     * @return array Calculation results
     */
    public function calculateQuoteTotal($lineItems)
    {
        $data = [
            'type' => 'QUOTE-TOTAL',
            'lineItems' => $lineItems
        ];
        
        return $this->callCobolService('/calculate', $data);
    }
    
    /**
     * Perform currency conversion using COBOL
     * 
     * @param float $amount Amount to convert
     * @param float $rate Exchange rate
     * @return array Calculation results
     */
    public function convertCurrency($amount, $rate)
    {
        $data = [
            'type' => 'CURRENCY-CONVERT',
            'principal' => $amount,
            'rate' => $rate
        ];
        
        return $this->callCobolService('/calculate', $data);
    }
    
    /**
     * Process batch calculations
     * 
     * @param array $calculations Array of calculation requests
     * @return array Batch results
     */
    public function batchCalculate($calculations)
    {
        $data = [
            'calculations' => $calculations
        ];
        
        return $this->callCobolService('/batch', $data);
    }
    
    /**
     * Call COBOL service via HTTP
     * 
     * @param string $endpoint API endpoint
     * @param array $data Request data
     * @return array Response data
     */
    private function callCobolService($endpoint, $data)
    {
        $url = $this->cobol_api_url . $endpoint;
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            $GLOBALS['log']->error("COBOL Bridge: cURL error - $error");
            return [
                'status' => 'error',
                'message' => 'Failed to connect to COBOL service',
                'error' => $error
            ];
        }
        
        if ($httpCode !== 200) {
            $GLOBALS['log']->error("COBOL Bridge: HTTP error - Code $httpCode");
            return [
                'status' => 'error',
                'message' => 'COBOL service returned an error',
                'httpCode' => $httpCode
            ];
        }
        
        $result = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $GLOBALS['log']->error("COBOL Bridge: JSON decode error - " . json_last_error_msg());
            return [
                'status' => 'error',
                'message' => 'Invalid response from COBOL service'
            ];
        }
        
        // Log successful calculations for audit
        if ($result['status'] === 'success') {
            $this->logCalculation($endpoint, $data, $result);
        }
        
        return $result;
    }
    
    /**
     * Get cached result
     * 
     * @param string $key Cache key
     * @return mixed Cached data or false
     */
    private function getFromCache($key)
    {
        global $sugar_config;
        
        if (!$this->cache_enabled) {
            return false;
        }
        
        $cacheFile = sugar_cached("cobol_bridge/$key.cache");
        
        if (file_exists($cacheFile)) {
            $data = unserialize(file_get_contents($cacheFile));
            if ($data['expires'] > time()) {
                return $data['value'];
            }
            unlink($cacheFile);
        }
        
        return false;
    }
    
    /**
     * Save result to cache
     * 
     * @param string $key Cache key
     * @param mixed $value Data to cache
     */
    private function saveToCache($key, $value)
    {
        if (!$this->cache_enabled) {
            return;
        }
        
        $cacheDir = sugar_cached("cobol_bridge");
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }
        
        $cacheFile = "$cacheDir/$key.cache";
        $data = [
            'value' => $value,
            'expires' => time() + $this->cache_ttl
        ];
        
        file_put_contents($cacheFile, serialize($data));
    }
    
    /**
     * Log calculation for audit trail
     * 
     * @param string $endpoint API endpoint
     * @param array $request Request data
     * @param array $response Response data
     */
    private function logCalculation($endpoint, $request, $response)
    {
        global $current_user;
        
        $log = BeanFactory::newBean('COBOL_Bridge_Audit');
        $log->name = $request['type'] ?? 'Unknown';
        $log->endpoint = $endpoint;
        $log->request_data = json_encode($request);
        $log->response_data = json_encode($response);
        $log->user_id = $current_user->id;
        $log->processing_time = $response['processingTime'] ?? null;
        $log->save();
    }
    
    /**
     * Test COBOL service connectivity
     * 
     * @return array Test results
     */
    public function testConnection()
    {
        $ch = curl_init($this->cobol_api_url . '/health');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'connected' => $httpCode === 200,
            'url' => $this->cobol_api_url,
            'response' => json_decode($response, true)
        ];
    }
}