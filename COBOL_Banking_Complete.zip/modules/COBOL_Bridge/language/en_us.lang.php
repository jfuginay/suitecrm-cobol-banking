<?php
/**
 * COBOL Bridge Language File - English
 */

$mod_strings = array(
    'LBL_MODULE_NAME' => 'COBOL Banking',
    'LBL_MODULE_TITLE' => 'COBOL Banking Integration',
    'LBL_MODULE_ID' => 'COBOL_Bridge',
    
    // Navigation
    'LBL_FINANCIAL_CALCULATOR' => 'Financial Calculator',
    'LBL_MAINFRAME_SYNC' => 'Mainframe Sync',
    'LBL_TRANSACTION_LEDGER' => 'Transaction Ledger',
    'LBL_BATCH_PROCESSING' => 'Batch Processing',
    'LBL_AUDIT_LOG' => 'COBOL Audit Log',
    
    // Calculator
    'LBL_CALC_TITLE' => 'COBOL Financial Calculator',
    'LBL_CALC_DESC' => 'Perform financial calculations with banking-grade COBOL precision',
    'LBL_SIMPLE_INTEREST' => 'Simple Interest',
    'LBL_COMPOUND_INTEREST' => 'Compound Interest',
    'LBL_LOAN_PAYMENT' => 'Loan Payment Calculator',
    'LBL_AMORTIZATION' => 'Amortization Schedule',
    'LBL_PRINCIPAL' => 'Principal Amount',
    'LBL_RATE' => 'Interest Rate',
    'LBL_TERM' => 'Term',
    'LBL_CALCULATE' => 'Calculate',
    
    // Mainframe Sync
    'LBL_SYNC_TITLE' => 'Mainframe Synchronization',
    'LBL_SYNC_DESC' => 'Synchronize CRM data with mainframe banking systems',
    'LBL_SYNC_ACCOUNTS' => 'Sync All Accounts',
    'LBL_SYNC_TRANSACTIONS' => 'Sync Transactions',
    'LBL_SYNC_BALANCES' => 'Update Balances',
    'LBL_LAST_SYNC' => 'Last Synchronization',
    'LBL_RECORDS_SYNCED' => 'Records Synced',
    
    // Transaction Ledger
    'LBL_LEDGER_TITLE' => 'Real-time Transaction Ledger',
    'LBL_LEDGER_DESC' => 'View live transaction feeds from mainframe systems',
    'LBL_ACCOUNT_FILTER' => 'Account Filter',
    'LBL_TRANSACTION_TYPE' => 'Transaction Type',
    'LBL_CONNECT_FEED' => 'Connect Live Feed',
    'LBL_EXPORT' => 'Export Transactions',
    
    // Status Messages
    'LBL_CONNECTED' => 'Connected',
    'LBL_DISCONNECTED' => 'Disconnected',
    'LBL_SYNC_IN_PROGRESS' => 'Synchronization in progress...',
    'LBL_SYNC_COMPLETE' => 'Synchronization completed',
    'LBL_SYNC_FAILED' => 'Synchronization failed',
    
    // COBOL Features
    'LBL_COBOL_POWERED' => 'Powered by COBOL',
    'LBL_BANKING_PRECISION' => 'Banking-grade decimal precision',
    'LBL_NO_ROUNDING_ERRORS' => 'No floating-point rounding errors',
    'LBL_MAINFRAME_COMPATIBLE' => 'Mainframe compatible calculations',
    
    // Admin
    'LBL_COBOL_CONFIG' => 'COBOL Configuration',
    'LBL_API_URL' => 'COBOL API URL',
    'LBL_WEBSOCKET_URL' => 'WebSocket URL',
    'LBL_ENABLE_INTEGRATION' => 'Enable COBOL Integration',
    'LBL_TEST_CONNECTION' => 'Test Connection',
    'LBL_SERVICE_STATUS' => 'Service Status',
    
    // Help Text
    'LBL_HELP_CALCULATOR' => 'Use COBOL-powered calculations for exact financial precision required by banking regulations.',
    'LBL_HELP_SYNC' => 'Synchronize your CRM data with mainframe systems in real-time or batch mode.',
    'LBL_HELP_LEDGER' => 'Monitor live transactions as they flow through your mainframe banking systems.',
);