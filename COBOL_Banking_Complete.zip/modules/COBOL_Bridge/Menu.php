<?php
/**
 * COBOL Bridge Module Menu
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $mod_strings, $app_strings, $sugar_config;

// Main module menu
if (ACLController::checkAccess('COBOL_Bridge', 'list', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=index',
        $mod_strings['LBL_MODULE_NAME'],
        'COBOL_Bridge',
        'COBOL_Bridge'
    );
}

// Financial Calculator
if (ACLController::checkAccess('COBOL_Bridge', 'view', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=calculator',
        'Financial Calculator',
        'Calculate',
        'COBOL_Bridge'
    );
}

// Mainframe Sync
if (ACLController::checkAccess('COBOL_Bridge', 'edit', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=mainframe_sync',
        'Mainframe Sync',
        'Sync',
        'COBOL_Bridge'
    );
}

// Transaction Ledger
if (ACLController::checkAccess('COBOL_Bridge', 'view', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=transaction_ledger',
        'Transaction Ledger',
        'Transactions',
        'COBOL_Bridge'
    );
}

// Batch Processing
if (ACLController::checkAccess('COBOL_Bridge', 'edit', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=batch_process',
        'Batch Processing',
        'Batch',
        'COBOL_Bridge'
    );
}

// COBOL Logs
if (ACLController::checkAccess('COBOL_Bridge', 'view', true)) {
    $module_menu[] = array(
        'index.php?module=COBOL_Bridge&action=audit_log',
        'COBOL Audit Log',
        'Logs',
        'COBOL_Bridge'
    );
}

// Settings (Admin only)
if (is_admin($current_user)) {
    $module_menu[] = array(
        'index.php?module=Administration&action=COBOLConfig',
        'COBOL Settings',
        'Settings',
        'Administration'
    );
}