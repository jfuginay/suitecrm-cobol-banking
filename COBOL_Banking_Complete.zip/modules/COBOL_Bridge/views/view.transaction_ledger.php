<?php
/**
 * Transaction Ledger View - Real-time transaction display from COBOL/Mainframe
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class COBOL_BridgeViewTransaction_ledger extends ViewDetail {
    
    public function display() {
        global $sugar_config;
        
        $websocket_url = !empty($sugar_config['cobol_websocket_url']) ? $sugar_config['cobol_websocket_url'] : 'ws://localhost:8081';
        
        echo <<<HTML
<style>
    .transaction-ledger {
        max-width: 1400px;
        margin: 20px auto;
    }
    .ledger-controls {
        background: white;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .ledger-table {
        background: white;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .transaction-row {
        border-bottom: 1px solid #eee;
        padding: 10px 0;
        transition: background-color 0.3s;
    }
    .transaction-row:hover {
        background-color: #f8f9fa;
    }
    .transaction-new {
        animation: highlight 2s ease-out;
    }
    @keyframes highlight {
        0% { background-color: #fff3cd; }
        100% { background-color: transparent; }
    }
    .amount-credit {
        color: #28a745;
        font-weight: bold;
    }
    .amount-debit {
        color: #dc3545;
        font-weight: bold;
    }
    .status-badge {
        padding: 3px 8px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: bold;
    }
    .status-posted { background: #d4edda; color: #155724; }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-failed { background: #f8d7da; color: #721c24; }
    .live-indicator {
        display: inline-block;
        width: 10px;
        height: 10px;
        background: #28a745;
        border-radius: 50%;
        margin-right: 5px;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    .connection-status {
        float: right;
        padding: 5px 10px;
        border-radius: 3px;
        font-size: 12px;
    }
    .connected { background: #d4edda; color: #155724; }
    .disconnected { background: #f8d7da; color: #721c24; }
</style>

<div class="moduleTitle">
    <h2>
        Transaction Ledger 
        <span class="live-indicator"></span>
        <small style="font-weight: normal;">Real-time from Mainframe</small>
        <span id="connection-status" class="connection-status disconnected">Disconnected</span>
    </h2>
    <div class="clear"></div>
</div>

<div class="transaction-ledger">
    <div class="ledger-controls">
        <div class="row">
            <div class="col-md-3">
                <label>Account Filter</label>
                <input type="text" id="account-filter" class="form-control" placeholder="Account number...">
            </div>
            <div class="col-md-3">
                <label>Transaction Type</label>
                <select id="type-filter" class="form-control">
                    <option value="">All Types</option>
                    <option value="DEPOSIT">Deposits</option>
                    <option value="WITHDRAWAL">Withdrawals</option>
                    <option value="TRANSFER">Transfers</option>
                    <option value="FEE">Fees</option>
                    <option value="INTEREST">Interest</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>Date Range</label>
                <select id="date-filter" class="form-control">
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                    <option value="all">All Time</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>&nbsp;</label>
                <div>
                    <button class="btn btn-primary" onclick="connectWebSocket()">
                        <i class="glyphicon glyphicon-play"></i> Connect Live Feed
                    </button>
                    <button class="btn btn-default" onclick="exportTransactions()">
                        <i class="glyphicon glyphicon-download"></i> Export
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="ledger-table">
        <table class="table" style="width: 100%;">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Account</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th style="text-align: right;">Amount</th>
                    <th style="text-align: right;">Balance</th>
                    <th>Status</th>
                    <th>Reference</th>
                </tr>
            </thead>
            <tbody id="transaction-list">
                <!-- Transactions will be loaded here -->
            </tbody>
        </table>
        
        <div id="no-transactions" style="text-align: center; padding: 40px; color: #999;">
            <p>No transactions to display. Click "Connect Live Feed" to start receiving transactions.</p>
        </div>
    </div>
    
    <div style="margin-top: 20px; text-align: center;">
        <small style="color: #666;">
            Transactions are streamed in real-time from the COBOL mainframe system via WebSocket connection.
        </small>
    </div>
</div>

<script>
var websocket = null;
var websocketUrl = '{$websocket_url}';
var transactions = [];
var filters = {
    account: '',
    type: '',
    dateRange: 'today'
};

// Sample transactions for demo
var sampleTransactions = [
    {
        timestamp: new Date().toISOString(),
        account: 'ACC10001',
        type: 'DEPOSIT',
        description: 'Direct Deposit - Payroll',
        amount: 3250.00,
        balance: 128900.32,
        status: 'POSTED',
        reference: 'DD' + Math.floor(Math.random() * 100000)
    },
    {
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        account: 'ACC10002',
        type: 'WITHDRAWAL',
        description: 'ATM Withdrawal',
        amount: -200.00,
        balance: 8745.12,
        status: 'POSTED',
        reference: 'ATM' + Math.floor(Math.random() * 100000)
    },
    {
        timestamp: new Date(Date.now() - 7200000).toISOString(),
        account: 'ACC10003',
        type: 'TRANSFER',
        description: 'Wire Transfer - Vendor Payment',
        amount: -15000.00,
        balance: 435123.89,
        status: 'PENDING',
        reference: 'WT' + Math.floor(Math.random() * 100000)
    }
];

function connectWebSocket() {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
        websocket.close();
        return;
    }
    
    updateConnectionStatus('Connecting...');
    
    websocket = new WebSocket(websocketUrl);
    
    websocket.onopen = function() {
        updateConnectionStatus('Connected', true);
        console.log('WebSocket connected');
        
        // Send authentication/subscription
        websocket.send(JSON.stringify({
            action: 'subscribe',
            filters: filters
        }));
        
        // Load sample transactions
        sampleTransactions.forEach(function(tx, index) {
            setTimeout(function() {
                addTransaction(tx);
            }, index * 1000);
        });
    };
    
    websocket.onmessage = function(event) {
        try {
            var transaction = JSON.parse(event.data);
            addTransaction(transaction);
        } catch (e) {
            console.error('Invalid transaction data:', e);
        }
    };
    
    websocket.onerror = function(error) {
        console.error('WebSocket error:', error);
        updateConnectionStatus('Connection Error', false);
    };
    
    websocket.onclose = function() {
        updateConnectionStatus('Disconnected', false);
        console.log('WebSocket disconnected');
    };
}

function updateConnectionStatus(status, connected) {
    var statusEl = document.getElementById('connection-status');
    statusEl.textContent = status;
    statusEl.className = 'connection-status ' + (connected ? 'connected' : 'disconnected');
}

function addTransaction(transaction) {
    transactions.unshift(transaction);
    
    // Apply filters
    if (!matchesFilters(transaction)) {
        return;
    }
    
    var tbody = document.getElementById('transaction-list');
    var noTxDiv = document.getElementById('no-transactions');
    
    noTxDiv.style.display = 'none';
    
    var row = document.createElement('tr');
    row.className = 'transaction-row transaction-new';
    
    var amountClass = transaction.amount >= 0 ? 'amount-credit' : 'amount-debit';
    var statusClass = 'status-' + transaction.status.toLowerCase();
    
    row.innerHTML = `
        <td>\${formatTime(transaction.timestamp)}</td>
        <td><strong>\${transaction.account}</strong></td>
        <td>\${transaction.type}</td>
        <td>\${transaction.description}</td>
        <td class="\${amountClass}" style="text-align: right;">
            \${formatAmount(transaction.amount)}
        </td>
        <td style="text-align: right;">\${formatAmount(transaction.balance)}</td>
        <td><span class="status-badge \${statusClass}">\${transaction.status}</span></td>
        <td style="font-family: monospace; font-size: 12px;">\${transaction.reference}</td>
    `;
    
    tbody.insertBefore(row, tbody.firstChild);
    
    // Keep only last 100 transactions in view
    while (tbody.children.length > 100) {
        tbody.removeChild(tbody.lastChild);
    }
}

function matchesFilters(transaction) {
    if (filters.account && !transaction.account.includes(filters.account)) {
        return false;
    }
    
    if (filters.type && transaction.type !== filters.type) {
        return false;
    }
    
    // Date filter logic here
    
    return true;
}

function formatTime(timestamp) {
    var date = new Date(timestamp);
    return date.toLocaleTimeString();
}

function formatAmount(amount) {
    var sign = amount < 0 ? '-' : '';
    return sign + '$' + Math.abs(amount).toFixed(2).replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
}

function exportTransactions() {
    // Create CSV content
    var csv = 'Time,Account,Type,Description,Amount,Balance,Status,Reference\\n';
    
    transactions.forEach(function(tx) {
        csv += [
            formatTime(tx.timestamp),
            tx.account,
            tx.type,
            '"' + tx.description + '"',
            tx.amount,
            tx.balance,
            tx.status,
            tx.reference
        ].join(',') + '\\n';
    });
    
    // Download file
    var blob = new Blob([csv], {type: 'text/csv'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'transactions_' + new Date().toISOString().split('T')[0] + '.csv';
    a.click();
}

// Filter event listeners
document.getElementById('account-filter').addEventListener('input', function(e) {
    filters.account = e.target.value;
    refreshDisplay();
});

document.getElementById('type-filter').addEventListener('change', function(e) {
    filters.type = e.target.value;
    refreshDisplay();
});

document.getElementById('date-filter').addEventListener('change', function(e) {
    filters.dateRange = e.target.value;
    refreshDisplay();
});

function refreshDisplay() {
    var tbody = document.getElementById('transaction-list');
    tbody.innerHTML = '';
    
    transactions.forEach(function(tx) {
        if (matchesFilters(tx)) {
            addTransaction(tx);
        }
    });
}

// Auto-generate random transactions for demo
function generateRandomTransaction() {
    if (!websocket || websocket.readyState !== WebSocket.OPEN) {
        return;
    }
    
    var accounts = ['ACC10001', 'ACC10002', 'ACC10003', 'ACC10004'];
    var types = ['DEPOSIT', 'WITHDRAWAL', 'TRANSFER', 'FEE'];
    var descriptions = [
        'Online Purchase', 'ATM Withdrawal', 'Direct Deposit',
        'Wire Transfer', 'Check Deposit', 'Service Fee',
        'Interest Credit', 'Mobile Deposit'
    ];
    
    var account = accounts[Math.floor(Math.random() * accounts.length)];
    var type = types[Math.floor(Math.random() * types.length)];
    var amount = type === 'DEPOSIT' ? 
        Math.random() * 5000 : 
        -(Math.random() * 1000);
    
    var transaction = {
        timestamp: new Date().toISOString(),
        account: account,
        type: type,
        description: descriptions[Math.floor(Math.random() * descriptions.length)],
        amount: parseFloat(amount.toFixed(2)),
        balance: Math.random() * 100000,
        status: Math.random() > 0.1 ? 'POSTED' : 'PENDING',
        reference: type.substr(0, 2) + Math.floor(Math.random() * 100000)
    };
    
    addTransaction(transaction);
}

// Generate a random transaction every 3-7 seconds when connected
setInterval(function() {
    if (Math.random() > 0.5) {
        generateRandomTransaction();
    }
}, 5000);
</script>

HTML;
    }
}