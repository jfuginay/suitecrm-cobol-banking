<?php
/**
 * COBOL Financial Calculator View - Interactive UI for COBOL calculations
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class COBOL_BridgeViewCalculator extends ViewDetail {
    
    public function display() {
        global $sugar_config;
        
        $cobol_url = !empty($sugar_config['cobol_api_url']) ? $sugar_config['cobol_api_url'] : 'http://localhost:3001';
        
        echo <<<HTML
<style>
    .cobol-calculator {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background: #f5f5f5;
        border-radius: 8px;
    }
    .calc-section {
        background: white;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .calc-input {
        margin-bottom: 15px;
    }
    .calc-input label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    .calc-input input, .calc-input select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .calc-button {
        background: #0066cc;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }
    .calc-button:hover {
        background: #0052a3;
    }
    .result-box {
        background: #e8f5e9;
        padding: 20px;
        border-radius: 5px;
        margin-top: 20px;
        display: none;
    }
    .error-box {
        background: #ffebee;
        padding: 20px;
        border-radius: 5px;
        margin-top: 20px;
        display: none;
        color: #c62828;
    }
    .cobol-indicator {
        background: #4caf50;
        color: white;
        padding: 5px 10px;
        border-radius: 3px;
        font-size: 12px;
        display: inline-block;
    }
</style>

<div class="moduleTitle">
    <h2>COBOL Financial Calculator <span class="cobol-indicator">Powered by COBOL</span></h2>
    <div class="clear"></div>
</div>

<div class="cobol-calculator">
    <div class="calc-section">
        <h3>Select Calculation Type</h3>
        <div class="calc-input">
            <select id="calc-type" onchange="updateForm()">
                <option value="">-- Select Calculation --</option>
                <option value="SIMPLE-INTEREST">Simple Interest</option>
                <option value="COMPOUND-INTEREST">Compound Interest</option>
                <option value="LOAN-PAYMENT">Loan Payment (Mortgage)</option>
                <option value="AMORTIZATION">Amortization Schedule</option>
                <option value="INVOICE-TOTAL">Invoice Total with Tax</option>
                <option value="CURRENCY-CONVERT">Currency Conversion</option>
            </select>
        </div>
    </div>
    
    <div id="calc-form" class="calc-section" style="display: none;">
        <h3>Enter Values</h3>
        
        <!-- Dynamic form fields will be inserted here -->
        <div id="dynamic-fields"></div>
        
        <button class="calc-button" onclick="performCalculation()">
            Calculate with COBOL Precision
        </button>
    </div>
    
    <div id="result-box" class="result-box">
        <h3>Calculation Results</h3>
        <div id="result-content"></div>
        <p style="margin-top: 10px; font-style: italic; color: #666;">
            Calculated using COBOL COMP-3 decimal precision - no floating point errors!
        </p>
    </div>
    
    <div id="error-box" class="error-box">
        <h3>Error</h3>
        <div id="error-content"></div>
    </div>
    
    <div class="calc-section">
        <h4>Why COBOL Calculations?</h4>
        <ul>
            <li>Banking-grade decimal precision (no rounding errors)</li>
            <li>Same calculations used by mainframe systems</li>
            <li>Regulatory compliance for financial institutions</li>
            <li>Perfect penny accuracy for large transactions</li>
        </ul>
    </div>
</div>

<script>
var cobolApiUrl = '{$cobol_url}';

function updateForm() {
    var calcType = document.getElementById('calc-type').value;
    var formDiv = document.getElementById('calc-form');
    var fieldsDiv = document.getElementById('dynamic-fields');
    
    if (!calcType) {
        formDiv.style.display = 'none';
        return;
    }
    
    formDiv.style.display = 'block';
    fieldsDiv.innerHTML = '';
    
    var fields = getFieldsForType(calcType);
    fields.forEach(function(field) {
        var html = '<div class="calc-input">';
        html += '<label>' + field.label + '</label>';
        html += '<input type="' + field.type + '" id="' + field.id + '" ';
        if (field.placeholder) html += 'placeholder="' + field.placeholder + '" ';
        if (field.step) html += 'step="' + field.step + '" ';
        if (field.value) html += 'value="' + field.value + '" ';
        html += 'required>';
        html += '</div>';
        fieldsDiv.innerHTML += html;
    });
}

function getFieldsForType(type) {
    switch(type) {
        case 'SIMPLE-INTEREST':
            return [
                {id: 'principal', label: 'Principal Amount ($)', type: 'number', step: '0.01', placeholder: '10000.00'},
                {id: 'rate', label: 'Annual Interest Rate (%)', type: 'number', step: '0.001', placeholder: '5.0'},
                {id: 'term', label: 'Term (days)', type: 'number', step: '1', placeholder: '365'}
            ];
        case 'COMPOUND-INTEREST':
            return [
                {id: 'principal', label: 'Principal Amount ($)', type: 'number', step: '0.01'},
                {id: 'rate', label: 'Annual Interest Rate (%)', type: 'number', step: '0.001'},
                {id: 'term', label: 'Term (years)', type: 'number', step: '1'},
                {id: 'frequency', label: 'Compounding Frequency (per year)', type: 'number', step: '1', value: '12'}
            ];
        case 'LOAN-PAYMENT':
            return [
                {id: 'principal', label: 'Loan Amount ($)', type: 'number', step: '0.01', placeholder: '250000.00'},
                {id: 'rate', label: 'Annual Interest Rate (%)', type: 'number', step: '0.001', placeholder: '4.5'},
                {id: 'term', label: 'Term (months)', type: 'number', step: '1', placeholder: '360'}
            ];
        case 'AMORTIZATION':
            return [
                {id: 'principal', label: 'Loan Amount ($)', type: 'number', step: '0.01'},
                {id: 'rate', label: 'Annual Interest Rate (%)', type: 'number', step: '0.001'},
                {id: 'term', label: 'Term (months)', type: 'number', step: '1'},
                {id: 'payment_number', label: 'Show Payment #', type: 'number', step: '1', value: '1'}
            ];
        case 'INVOICE-TOTAL':
            return [
                {id: 'subtotal', label: 'Subtotal ($)', type: 'number', step: '0.01'},
                {id: 'tax_rate', label: 'Tax Rate (%)', type: 'number', step: '0.001'},
                {id: 'discount', label: 'Discount ($)', type: 'number', step: '0.01', value: '0'}
            ];
        case 'CURRENCY-CONVERT':
            return [
                {id: 'amount', label: 'Amount', type: 'number', step: '0.01'},
                {id: 'from_currency', label: 'From Currency (USD)', type: 'text', value: 'USD'},
                {id: 'to_currency', label: 'To Currency (EUR)', type: 'text', value: 'EUR'},
                {id: 'rate', label: 'Exchange Rate', type: 'number', step: '0.0001', value: '0.85'}
            ];
    }
    return [];
}

function performCalculation() {
    var calcType = document.getElementById('calc-type').value;
    var data = {type: calcType};
    
    // Collect input values
    var inputs = document.querySelectorAll('#dynamic-fields input');
    inputs.forEach(function(input) {
        var value = input.value;
        if (input.type === 'number') {
            value = parseFloat(value);
        }
        
        // Map field IDs to API parameters
        if (input.id === 'rate') {
            data.rate = value / 100; // Convert percentage to decimal
        } else if (input.id === 'tax_rate') {
            data.tax_rate = value / 100;
        } else {
            data[input.id] = value;
        }
    });
    
    // Show loading
    document.getElementById('result-box').style.display = 'none';
    document.getElementById('error-box').style.display = 'none';
    
    // Call COBOL API
    fetch(cobolApiUrl + '/calculate', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.error) {
            showError(result.error);
        } else {
            showResult(result, calcType);
        }
    })
    .catch(error => {
        showError('Failed to connect to COBOL service: ' + error.message);
    });
}

function showResult(result, calcType) {
    var resultBox = document.getElementById('result-box');
    var resultContent = document.getElementById('result-content');
    
    var html = '';
    
    switch(calcType) {
        case 'SIMPLE-INTEREST':
            html = '<p><strong>Interest Amount:</strong> $' + formatMoney(result.interest) + '</p>';
            html += '<p><strong>Total Amount:</strong> $' + formatMoney(result.total) + '</p>';
            break;
        case 'COMPOUND-INTEREST':
            html = '<p><strong>Final Amount:</strong> $' + formatMoney(result.final_amount) + '</p>';
            html += '<p><strong>Total Interest:</strong> $' + formatMoney(result.total_interest) + '</p>';
            break;
        case 'LOAN-PAYMENT':
            html = '<p><strong>Monthly Payment:</strong> $' + formatMoney(result.payment) + '</p>';
            html += '<p><strong>Total Payments:</strong> $' + formatMoney(result.total_payments) + '</p>';
            html += '<p><strong>Total Interest:</strong> $' + formatMoney(result.total_interest) + '</p>';
            break;
        case 'AMORTIZATION':
            html = '<p><strong>Payment #' + result.payment_number + '</strong></p>';
            html += '<p><strong>Principal:</strong> $' + formatMoney(result.principal_payment) + '</p>';
            html += '<p><strong>Interest:</strong> $' + formatMoney(result.interest_payment) + '</p>';
            html += '<p><strong>Balance:</strong> $' + formatMoney(result.remaining_balance) + '</p>';
            break;
        case 'INVOICE-TOTAL':
            html = '<p><strong>Subtotal:</strong> $' + formatMoney(result.subtotal) + '</p>';
            html += '<p><strong>Tax:</strong> $' + formatMoney(result.tax) + '</p>';
            html += '<p><strong>Discount:</strong> $' + formatMoney(result.discount) + '</p>';
            html += '<p><strong>Total:</strong> $' + formatMoney(result.total) + '</p>';
            break;
        case 'CURRENCY-CONVERT':
            html = '<p><strong>Converted Amount:</strong> ' + result.converted_amount + ' ' + result.to_currency + '</p>';
            html += '<p><strong>Exchange Rate Used:</strong> ' + result.rate + '</p>';
            break;
    }
    
    html += '<p style="margin-top: 10px;"><small>Calculation performed at: ' + new Date().toLocaleString() + '</small></p>';
    
    resultContent.innerHTML = html;
    resultBox.style.display = 'block';
}

function showError(message) {
    var errorBox = document.getElementById('error-box');
    var errorContent = document.getElementById('error-content');
    
    errorContent.innerHTML = '<p>' + message + '</p>';
    errorBox.style.display = 'block';
}

function formatMoney(amount) {
    return parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
</script>

HTML;
    }
}