<?php
/**
 * Batch Processing View - Run COBOL batch jobs
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class COBOL_BridgeViewBatch_process extends ViewDetail {
    
    public function display() {
        global $sugar_config;
        
        $cobol_url = !empty($sugar_config['cobol_api_url']) ? $sugar_config['cobol_api_url'] : 'http://localhost:3001';
        
        echo <<<HTML
<style>
    .batch-container {
        max-width: 1200px;
        margin: 20px auto;
    }
    .batch-panel {
        background: white;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .job-card {
        border: 1px solid #dee2e6;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 15px;
        cursor: pointer;
        transition: all 0.3s;
    }
    .job-card:hover {
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        transform: translateY(-2px);
    }
    .job-card.selected {
        border-color: #007bff;
        background: #e3f2fd;
    }
    .job-icon {
        font-size: 48px;
        color: #6c757d;
        margin-bottom: 10px;
    }
    .run-button {
        background: #28a745;
        color: white;
        padding: 12px 30px;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
    }
    .run-button:hover {
        background: #218838;
    }
    .run-button:disabled {
        background: #6c757d;
        cursor: not-allowed;
    }
    .progress-container {
        margin-top: 20px;
        display: none;
    }
    .batch-log {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 4px;
        font-family: monospace;
        font-size: 12px;
        max-height: 300px;
        overflow-y: auto;
        margin-top: 20px;
    }
    .cobol-badge {
        background: #6f42c1;
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 11px;
    }
</style>

<div class="moduleTitle">
    <h2>COBOL Batch Processing</h2>
    <div class="clear"></div>
</div>

<div class="batch-container">
    <div class="batch-panel">
        <h3>Select Batch Job <span class="cobol-badge">COBOL Powered</span></h3>
        <p>Choose a batch job to run. These jobs execute COBOL programs on the mainframe.</p>
        
        <div class="row">
            <div class="col-md-4">
                <div class="job-card" data-job="daily-interest">
                    <div class="text-center">
                        <div class="job-icon">💰</div>
                        <h4>Daily Interest Calculation</h4>
                        <p>Calculate and post interest for all savings accounts</p>
                        <small>Runs: Daily at 2:00 AM</small>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="job-card" data-job="monthly-statements">
                    <div class="text-center">
                        <div class="job-icon">📄</div>
                        <h4>Generate Monthly Statements</h4>
                        <p>Create PDF statements for all active accounts</p>
                        <small>Runs: 1st of each month</small>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="job-card" data-job="regulatory-report">
                    <div class="text-center">
                        <div class="job-icon">📊</div>
                        <h4>Regulatory Reports</h4>
                        <p>Generate compliance reports for banking authorities</p>
                        <small>Runs: Quarterly</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row" style="margin-top: 15px;">
            <div class="col-md-4">
                <div class="job-card" data-job="account-reconciliation">
                    <div class="text-center">
                        <div class="job-icon">🔄</div>
                        <h4>Account Reconciliation</h4>
                        <p>Reconcile CRM accounts with mainframe</p>
                        <small>Runs: Weekly</small>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="job-card" data-job="dormant-accounts">
                    <div class="text-center">
                        <div class="job-icon">😴</div>
                        <h4>Dormant Account Check</h4>
                        <p>Identify and flag inactive accounts</p>
                        <small>Runs: Monthly</small>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="job-card" data-job="fee-processing">
                    <div class="text-center">
                        <div class="job-icon">💳</div>
                        <h4>Fee Processing</h4>
                        <p>Calculate and apply monthly service fees</p>
                        <small>Runs: Last day of month</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="batch-panel">
        <h3>Job Configuration</h3>
        <div id="job-config" style="display: none;">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Processing Date</label>
                        <input type="date" id="process-date" class="form-control" value="{$smarty.now|date_format:'%Y-%m-%d'}">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Account Range (Optional)</label>
                        <input type="text" id="account-range" class="form-control" placeholder="e.g., ACC10000-ACC19999">
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>
                    <input type="checkbox" id="test-mode"> Run in Test Mode (no changes will be saved)
                </label>
            </div>
            
            <button class="run-button" onclick="runBatchJob()">
                Run Batch Job
            </button>
        </div>
        
        <div id="no-selection" style="text-align: center; padding: 40px; color: #999;">
            Select a batch job above to configure and run
        </div>
    </div>
    
    <div class="progress-container" id="progress-container">
        <div class="batch-panel">
            <h3>Job Progress</h3>
            <div style="background: #e0e0e0; height: 30px; border-radius: 15px; overflow: hidden;">
                <div id="progress-bar" style="background: #007bff; height: 100%; width: 0%; transition: width 0.5s;">
                    <span id="progress-text" style="color: white; line-height: 30px; padding-left: 15px;">0%</span>
                </div>
            </div>
            
            <div class="batch-log" id="batch-log">
                <!-- Log messages will appear here -->
            </div>
        </div>
    </div>
    
    <div class="batch-panel">
        <h3>Recent Batch Jobs</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Job Type</th>
                    <th>Started</th>
                    <th>Duration</th>
                    <th>Records Processed</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Daily Interest Calculation</td>
                    <td>{$smarty.now|date_format:'%Y-%m-%d 02:00:00'}</td>
                    <td>5m 32s</td>
                    <td>15,234</td>
                    <td><span class="label label-success">Completed</span></td>
                    <td><a href="#" onclick="viewJobLog('job1')">View Log</a></td>
                </tr>
                <tr>
                    <td>Monthly Statements</td>
                    <td>{$smarty.now|date_format:'%Y-%m-01 03:00:00'}</td>
                    <td>45m 18s</td>
                    <td>8,912</td>
                    <td><span class="label label-success">Completed</span></td>
                    <td><a href="#" onclick="viewJobLog('job2')">View Log</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
var selectedJob = null;
var cobolApiUrl = '{$cobol_url}';

// Job selection
document.querySelectorAll('.job-card').forEach(function(card) {
    card.addEventListener('click', function() {
        // Remove previous selection
        document.querySelectorAll('.job-card').forEach(function(c) {
            c.classList.remove('selected');
        });
        
        // Select this card
        this.classList.add('selected');
        selectedJob = this.getAttribute('data-job');
        
        // Show configuration
        document.getElementById('job-config').style.display = 'block';
        document.getElementById('no-selection').style.display = 'none';
    });
});

function runBatchJob() {
    if (!selectedJob) {
        alert('Please select a batch job');
        return;
    }
    
    var processDate = document.getElementById('process-date').value;
    var accountRange = document.getElementById('account-range').value;
    var testMode = document.getElementById('test-mode').checked;
    
    // Show progress
    document.getElementById('progress-container').style.display = 'block';
    var logDiv = document.getElementById('batch-log');
    logDiv.innerHTML = '';
    
    // Disable run button
    document.querySelector('.run-button').disabled = true;
    
    addLogMessage('Starting batch job: ' + selectedJob);
    addLogMessage('Process date: ' + processDate);
    if (testMode) addLogMessage('Running in TEST MODE');
    
    updateProgress(10);
    addLogMessage('Connecting to COBOL batch processor...');
    
    // Simulate batch processing
    setTimeout(function() {
        updateProgress(20);
        addLogMessage('Connected to mainframe');
        addLogMessage('Loading COBOL program: ' + getCobolProgram(selectedJob));
        
        setTimeout(function() {
            updateProgress(40);
            addLogMessage('Processing records...');
            
            var recordCount = 0;
            var interval = setInterval(function() {
                recordCount += Math.floor(Math.random() * 100) + 50;
                addLogMessage('Processed ' + recordCount + ' records');
                
                var progress = Math.min(40 + (recordCount / 10000) * 40, 80);
                updateProgress(progress);
                
                if (recordCount > 8000) {
                    clearInterval(interval);
                    
                    updateProgress(90);
                    addLogMessage('Finalizing batch job...');
                    
                    setTimeout(function() {
                        updateProgress(100);
                        addLogMessage('Batch job completed successfully!');
                        addLogMessage('Total records processed: ' + recordCount);
                        addLogMessage('Duration: 2m 15s');
                        
                        // Re-enable button
                        document.querySelector('.run-button').disabled = false;
                        
                        // Log to database
                        logBatchJob(selectedJob, recordCount);
                    }, 2000);
                }
            }, 1000);
        }, 2000);
    }, 1000);
}

function getCobolProgram(jobType) {
    var programs = {
        'daily-interest': 'INTCALC.COB',
        'monthly-statements': 'STMTGEN.COB',
        'regulatory-report': 'REGPRPT.COB',
        'account-reconciliation': 'ACCTREC.COB',
        'dormant-accounts': 'DORMCHK.COB',
        'fee-processing': 'FEEPROC.COB'
    };
    return programs[jobType] || 'UNKNOWN.COB';
}

function updateProgress(percent) {
    document.getElementById('progress-bar').style.width = percent + '%';
    document.getElementById('progress-text').textContent = percent + '%';
}

function addLogMessage(message) {
    var logDiv = document.getElementById('batch-log');
    var timestamp = new Date().toLocaleTimeString();
    logDiv.innerHTML += '[' + timestamp + '] ' + message + '\\n';
    logDiv.scrollTop = logDiv.scrollHeight;
}

function viewJobLog(jobId) {
    alert('View detailed log for job ' + jobId);
    // Would open detailed log view
}

function logBatchJob(jobType, recordCount) {
    // Log batch job execution to database
    fetch('index.php?module=COBOL_Bridge&action=LogBatch&sugar_body_only=1', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            job_type: jobType,
            record_count: recordCount,
            status: 'completed'
        })
    });
}
</script>

HTML;
    }
}