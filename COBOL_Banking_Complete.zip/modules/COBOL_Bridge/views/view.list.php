<?php
/**
 * COBOL Bridge List View - Shows all COBOL calculations and operations
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.list.php');

class COBOL_BridgeViewList extends ViewList {
    
    public function preDisplay() {
        parent::preDisplay();
        
        // Add custom buttons to list view
        $this->lv->actionsMenuExtraItems[] = $this->buildMyMenuItem();
    }
    
    public function display() {
        // Add JavaScript for COBOL operations
        echo <<<EOQ
        <script type="text/javascript">
        function performCobolCalculation() {
            window.location = 'index.php?module=COBOL_Bridge&action=calculator';
        }
        
        function syncWithMainframe() {
            if(confirm('Sync all accounts with mainframe?')) {
                window.location = 'index.php?module=COBOL_Bridge&action=mainframe_sync';
            }
        }
        </script>
        
        <div class="moduleTitle">
            <h2>COBOL Financial Operations</h2>
            <div class="clear"></div>
        </div>
        
        <div style="padding: 10px;">
            <button class="button primary" onclick="performCobolCalculation()">
                Open Financial Calculator
            </button>
            <button class="button" onclick="syncWithMainframe()">
                Sync with Mainframe
            </button>
        </div>
EOQ;
        
        parent::display();
    }
    
    private function buildMyMenuItem() {
        return <<<EOQ
        <a href="javascript:void(0)" onclick="performCobolCalculation()">
            Run COBOL Calculation
        </a>
EOQ;
    }
}